param(
    [ValidateSet("auto", "msvc", "clang", "gcc", "zig")]
    [string]$Compiler = "auto",
    [string]$OutDir = "."
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

$BuildDir = Join-Path $Root "build"
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$Sources = @(
    "src\beatpass_main.c",
    "src\beatpass_core.c",
    "src\beatpass_crypto.c",
    "src\beatpass_unicode.c",
    "src\beatpass_gui.c",
    "src\third_party\argon2\src\argon2.c",
    "src\third_party\argon2\src\core.c",
    "src\third_party\argon2\src\encoding.c",
    "src\third_party\argon2\src\ref.c",
    "src\third_party\argon2\src\thread.c",
    "src\third_party\argon2\src\blake2\blake2b.c"
)

$Includes = @(
    "src",
    "src\third_party\argon2\include",
    "src\third_party\argon2\src",
    "src\third_party\argon2\src\blake2"
)

function Find-Tool($name) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Get-Compiler {
    if ($Compiler -ne "auto") { return $Compiler }
    if (Find-Tool "cl.exe") { return "msvc" }
    if (Find-Tool "clang.exe") { return "clang" }
    if (Find-Tool "gcc.exe") { return "gcc" }
    if (Find-Tool "zig.exe") { return "zig" }
    throw "No C compiler found. Install MSVC Build Tools, LLVM/clang, MinGW gcc, or put zig.exe in PATH."
}

function New-MsvcResource {
    $rc = Find-Tool "rc.exe"
    if (-not $rc) {
        Write-Warning "rc.exe not found; building without icon/version resource."
        return $null
    }
    $res = Join-Path $BuildDir "BeatPass.res"
    & $rc /nologo /i . /i src /fo $res "src\BeatPass.rc"
    if ($LASTEXITCODE -ne 0) { throw "Resource compilation failed." }
    return $res
}

function New-GnuResource {
    $windres = Find-Tool "windres.exe"
    if (-not $windres) {
        Write-Warning "windres.exe not found; building without icon/version resource."
        return $null
    }
    $res = Join-Path $BuildDir "BeatPass.res.o"
    & $windres -I . -I src "src\BeatPass.rc" $res
    if ($LASTEXITCODE -ne 0) { throw "Resource compilation failed." }
    return $res
}

function New-ZigResource {
    $zig = Find-Tool "zig.exe"
    if (-not $zig) {
        Write-Warning "zig.exe not found; building without icon/version resource."
        return $null
    }
    $res = Join-Path $BuildDir "BeatPass.res"
    & $zig rc /c 65001 /i . /i src /fo $res "src\BeatPass.rc"
    if ($LASTEXITCODE -ne 0) { throw "Resource compilation failed." }
    return $res
}

$Selected = Get-Compiler
$Output = Join-Path $OutDir "BeatPass.exe"

Write-Host "Building BeatPass.exe with $Selected..."

if ($Selected -eq "msvc") {
    $cl = Find-Tool "cl.exe"
    $res = New-MsvcResource
    $includeArgs = $Includes | ForEach-Object { "/I$_" }
    $compilerArgs = @(
        "/nologo",
        "/std:c11",
        "/O2",
        "/W4",
        "/utf-8",
        "/D_CRT_SECURE_NO_WARNINGS",
        "/DUNICODE",
        "/D_UNICODE",
        "/DARGON2_NO_THREADS"
    ) + $includeArgs + $Sources
    if ($res) { $compilerArgs += $res }
    $compilerArgs += @(
        "/Fe:$Output",
        "/link",
        "/SUBSYSTEM:WINDOWS",
        "user32.lib",
        "gdi32.lib",
        "comctl32.lib",
        "shell32.lib",
        "dwmapi.lib",
        "bcrypt.lib",
        "normaliz.lib"
    )
    & $cl @compilerArgs
    if ($LASTEXITCODE -ne 0) { throw "Build failed." }
} elseif ($Selected -eq "zig") {
    $zig = Find-Tool "zig.exe"
    $res = New-ZigResource
    $includeArgs = $Includes | ForEach-Object { "-I$_" }
    $compilerArgs = @(
        "cc",
        "-target", "x86_64-windows-gnu",
        "-std=c11",
        "-O2",
        "-g0",
        "-Wall",
        "-Wextra",
        "-DUNICODE",
        "-D_UNICODE",
        "-DARGON2_NO_THREADS"
    ) + $includeArgs + $Sources
    if ($res) { $compilerArgs += $res }
    $compilerArgs += @(
        "-o", $Output,
        "-Wl,--subsystem,windows",
        "-luser32",
        "-lgdi32",
        "-lcomctl32",
        "-lshell32",
        "-ldwmapi",
        "-lbcrypt",
        "-lnormaliz"
    )
    & $zig @compilerArgs
    if ($LASTEXITCODE -ne 0) { throw "Build failed." }
} else {
    $cc = Find-Tool "$Selected.exe"
    $res = New-GnuResource
    $includeArgs = $Includes | ForEach-Object { "-I$_" }
    $compilerArgs = @(
        "-std=c11",
        "-mwindows",
        "-O2",
        "-g0",
        "-Wall",
        "-Wextra",
        "-DUNICODE",
        "-D_UNICODE",
        "-DARGON2_NO_THREADS"
    ) + $includeArgs + $Sources
    if ($res) { $compilerArgs += $res }
    $compilerArgs += @(
        "-o", $Output,
        "-Wl,--subsystem,windows",
        "-luser32",
        "-lgdi32",
        "-lcomctl32",
        "-lshell32",
        "-ldwmapi",
        "-lbcrypt",
        "-lnormaliz"
    )
    & $cc @compilerArgs
    if ($LASTEXITCODE -ne 0) { throw "Build failed." }
}

$Pdb = [System.IO.Path]::ChangeExtension((Resolve-Path -LiteralPath $Output).Path, ".pdb")
if (Test-Path -LiteralPath $Pdb) {
    Remove-Item -LiteralPath $Pdb -Force
}

Write-Host "Built $Output"
