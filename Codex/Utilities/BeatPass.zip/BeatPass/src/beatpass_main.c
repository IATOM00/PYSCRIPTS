#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#include "beatpass.h"

static int is_valid_handle(HANDLE handle) {
    return handle != NULL && handle != INVALID_HANDLE_VALUE;
}

static HANDLE std_handle_for(FILE *fallback) {
    return fallback == stderr ? GetStdHandle(STD_ERROR_HANDLE)
                              : GetStdHandle(STD_OUTPUT_HANDLE);
}

static void set_console_output_handle(DWORD std_id) {
    HANDLE handle = CreateFileW(L"CONOUT$",
                                GENERIC_READ | GENERIC_WRITE,
                                FILE_SHARE_READ | FILE_SHARE_WRITE,
                                NULL,
                                OPEN_EXISTING,
                                FILE_ATTRIBUTE_NORMAL,
                                NULL);
    if (is_valid_handle(handle)) {
        SetStdHandle(std_id, handle);
    }
}

static void prepare_cli_output(void) {
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    HANDLE err = GetStdHandle(STD_ERROR_HANDLE);
    int missing_out = !is_valid_handle(out);
    int missing_err = !is_valid_handle(err);

    if (!missing_out && !missing_err) {
        return;
    }

    if (AttachConsole(ATTACH_PARENT_PROCESS)) {
        if (missing_out) {
            set_console_output_handle(STD_OUTPUT_HANDLE);
        }
        if (missing_err) {
            set_console_output_handle(STD_ERROR_HANDLE);
        }
    }
}

static void write_utf8(FILE *fallback, const char *text) {
    HANDLE handle = std_handle_for(fallback);
    DWORD written = 0;
    size_t len = text ? strlen(text) : 0;

    if (len == 0) {
        return;
    }

    if (is_valid_handle(handle) &&
        WriteFile(handle, text, (DWORD)len, &written, NULL)) {
        return;
    }

    fwrite(text, 1, len, fallback);
}

static void write_wide(FILE *fallback, const wchar_t *text) {
    DWORD mode;
    HANDLE handle = std_handle_for(fallback);
    int needed;
    char *utf8;

    if (is_valid_handle(handle) && GetConsoleMode(handle, &mode)) {
        DWORD written = 0;
        WriteConsoleW(handle, text, (DWORD)wcslen(text), &written, NULL);
        return;
    }

    needed = WideCharToMultiByte(CP_UTF8,
                                 0,
                                 text,
                                 -1,
                                 NULL,
                                 0,
                                 NULL,
                                 NULL);
    if (needed <= 1) {
        return;
    }
    utf8 = (char *)malloc((size_t)needed);
    if (!utf8) {
        return;
    }
    if (WideCharToMultiByte(CP_UTF8,
                            0,
                            text,
                            -1,
                            utf8,
                            needed,
                            NULL,
                            NULL) > 0) {
        if (is_valid_handle(handle)) {
            DWORD written = 0;
            WriteFile(handle, utf8, (DWORD)needed - 1, &written, NULL);
        } else {
            fwrite(utf8, 1, (size_t)needed - 1, fallback);
        }
    }
    free(utf8);
}

static void print_usage(void) {
    write_wide(stdout,
               L"BeatPass deterministic password generator\n"
               L"\n"
               L"GUI:\n"
               L"  BeatPass.exe\n"
               L"\n"
               L"CLI:\n"
               L"  BeatPass.exe --secret \"мій секрет\" --difficulty maximum\n"
               L"\n"
               L"Difficulty: maximum, medium, minimum, normal\n");
}

static int starts_with(const wchar_t *value, const wchar_t *prefix) {
    return wcsncmp(value, prefix, wcslen(prefix)) == 0;
}

int main(void) {
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    const wchar_t *secret = NULL;
    const wchar_t *difficulty = bp_default_difficulty();
    wchar_t error[BP_ERROR_CAP];
    char password[BP_MAX_PASSWORD_LEN + 1];
    int rc;
    int i;

    if (!argv) {
        return 1;
    }

    if (argc <= 1) {
        LocalFree(argv);
        return bp_gui_run();
    }

    prepare_cli_output();

    for (i = 1; i < argc; ++i) {
        const wchar_t *arg = argv[i];

        if (wcscmp(arg, L"--help") == 0 || wcscmp(arg, L"-h") == 0) {
            print_usage();
            LocalFree(argv);
            return 0;
        }

        if (wcscmp(arg, L"--secret") == 0) {
            if (i + 1 >= argc) {
                write_wide(stderr, L"Помилка: --secret потребує значення.\n");
                LocalFree(argv);
                return 1;
            }
            secret = argv[++i];
            continue;
        }
        if (starts_with(arg, L"--secret=")) {
            secret = arg + wcslen(L"--secret=");
            continue;
        }

        if (wcscmp(arg, L"--difficulty") == 0) {
            if (i + 1 >= argc) {
                write_wide(stderr, L"Помилка: --difficulty потребує значення.\n");
                LocalFree(argv);
                return 1;
            }
            difficulty = argv[++i];
            continue;
        }
        if (starts_with(arg, L"--difficulty=")) {
            difficulty = arg + wcslen(L"--difficulty=");
            continue;
        }

        write_wide(stderr, L"Помилка: невідомий аргумент.\n");
        print_usage();
        LocalFree(argv);
        return 1;
    }

    if (!secret) {
        write_wide(stderr, L"Помилка: для CLI режиму вкажіть --secret.\n");
        print_usage();
        LocalFree(argv);
        return 1;
    }

    rc = bp_generate_key(secret,
                         difficulty,
                         password,
                         error,
                         sizeof(error) / sizeof(error[0]));
    if (rc != BP_OK) {
        write_wide(stderr, L"Помилка: ");
        write_wide(stderr, error);
        write_wide(stderr, L"\n");
        LocalFree(argv);
        return 1;
    }

    write_utf8(stdout, password);
    write_utf8(stdout, "\n");
    LocalFree(argv);
    return 0;
}

int WINAPI wWinMain(HINSTANCE instance,
                    HINSTANCE previous_instance,
                    PWSTR command_line,
                    int show_command) {
    (void)instance;
    (void)previous_instance;
    (void)command_line;
    (void)show_command;
    return main();
}
