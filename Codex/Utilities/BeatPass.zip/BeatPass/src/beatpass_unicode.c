#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdlib.h>
#include <string.h>
#include <wctype.h>

#include "beatpass_unicode.h"

int bp_nfkc(const wchar_t *input, wchar_t **out) {
    int needed;
    wchar_t *buffer;

    if (!input || !out) {
        return 0;
    }
    *out = NULL;

    needed = NormalizeString(NormalizationKC, input, -1, NULL, 0);
    if (needed <= 0) {
        return 0;
    }

    buffer = (wchar_t *)calloc((size_t)needed + 1, sizeof(wchar_t));
    if (!buffer) {
        return 0;
    }

    if (NormalizeString(NormalizationKC, input, -1, buffer, needed) <= 0) {
        free(buffer);
        return 0;
    }

    *out = buffer;
    return 1;
}

static int lower_invariant(const wchar_t *input, wchar_t **out) {
    int needed;
    wchar_t *buffer;

    needed = LCMapStringEx(LOCALE_NAME_INVARIANT,
                           LCMAP_LOWERCASE,
                           input,
                           -1,
                           NULL,
                           0,
                           NULL,
                           NULL,
                           0);
    if (needed <= 0) {
        return 0;
    }

    buffer = (wchar_t *)calloc((size_t)needed + 1, sizeof(wchar_t));
    if (!buffer) {
        return 0;
    }

    if (LCMapStringEx(LOCALE_NAME_INVARIANT,
                      LCMAP_LOWERCASE,
                      input,
                      -1,
                      buffer,
                      needed,
                      NULL,
                      NULL,
                      0) <= 0) {
        free(buffer);
        return 0;
    }

    *out = buffer;
    return 1;
}

int bp_casefold(const wchar_t *input, wchar_t **out) {
    wchar_t *lowered;
    size_t extra = 0;
    size_t i;
    size_t j;
    size_t len;
    wchar_t *folded;

    if (!input || !out) {
        return 0;
    }
    *out = NULL;

    if (!lower_invariant(input, &lowered)) {
        return 0;
    }

    len = wcslen(lowered);
    for (i = 0; i < len; ++i) {
        if (lowered[i] == 0x00DF || lowered[i] == 0x1E9E) {
            ++extra;
        }
    }

    folded = (wchar_t *)calloc(len + extra + 1, sizeof(wchar_t));
    if (!folded) {
        free(lowered);
        return 0;
    }

    for (i = 0, j = 0; i < len; ++i) {
        if (lowered[i] == 0x00DF || lowered[i] == 0x1E9E) {
            folded[j++] = L's';
            folded[j++] = L's';
        } else if (lowered[i] == 0x03C2) {
            folded[j++] = 0x03C3;
        } else {
            folded[j++] = lowered[i];
        }
    }
    folded[j] = L'\0';

    free(lowered);
    *out = folded;
    return 1;
}

int bp_to_utf8(const wchar_t *input, char **out, size_t *out_len) {
    int needed;
    char *buffer;

    if (!input || !out || !out_len) {
        return 0;
    }
    *out = NULL;
    *out_len = 0;

    needed = WideCharToMultiByte(CP_UTF8,
                                 WC_ERR_INVALID_CHARS,
                                 input,
                                 -1,
                                 NULL,
                                 0,
                                 NULL,
                                 NULL);
    if (needed <= 0) {
        return 0;
    }

    buffer = (char *)calloc((size_t)needed, sizeof(char));
    if (!buffer) {
        return 0;
    }

    if (WideCharToMultiByte(CP_UTF8,
                            WC_ERR_INVALID_CHARS,
                            input,
                            -1,
                            buffer,
                            needed,
                            NULL,
                            NULL) <= 0) {
        free(buffer);
        return 0;
    }

    *out = buffer;
    *out_len = (size_t)needed - 1;
    return 1;
}

size_t bp_codepoint_len(const wchar_t *text) {
    size_t count = 0;
    size_t i = 0;

    if (!text) {
        return 0;
    }

    while (text[i]) {
        if (text[i] >= 0xD800 && text[i] <= 0xDBFF &&
            text[i + 1] >= 0xDC00 && text[i + 1] <= 0xDFFF) {
            i += 2;
        } else {
            ++i;
        }
        ++count;
    }

    return count;
}

int bp_is_space(wchar_t ch) {
    if (iswspace((wint_t)ch)) {
        return 1;
    }

    switch (ch) {
    case 0x00A0:
    case 0x1680:
    case 0x2000:
    case 0x2001:
    case 0x2002:
    case 0x2003:
    case 0x2004:
    case 0x2005:
    case 0x2006:
    case 0x2007:
    case 0x2008:
    case 0x2009:
    case 0x200A:
    case 0x2028:
    case 0x2029:
    case 0x202F:
    case 0x205F:
    case 0x3000:
        return 1;
    default:
        return 0;
    }
}

int bp_has_outer_space(const wchar_t *text) {
    size_t len;

    if (!text || !text[0]) {
        return 0;
    }

    len = wcslen(text);
    return bp_is_space(text[0]) || bp_is_space(text[len - 1]);
}

wchar_t *bp_remove_spaces(const wchar_t *text) {
    size_t len;
    wchar_t *buffer;
    size_t i;
    size_t j = 0;

    if (!text) {
        return NULL;
    }

    len = wcslen(text);
    buffer = (wchar_t *)calloc(len + 1, sizeof(wchar_t));
    if (!buffer) {
        return NULL;
    }

    for (i = 0; i < len; ++i) {
        if (!bp_is_space(text[i])) {
            buffer[j++] = text[i];
        }
    }
    buffer[j] = L'\0';
    return buffer;
}
