#ifndef BEATPASS_CONTEXT_LOCAL_H
#define BEATPASS_CONTEXT_LOCAL_H

#define BP_CONTEXT_KEY_MINIMUM "min"
#define BP_CONTEXT_KEY_MEDIUM "medium"
#define BP_CONTEXT_KEY_MAXIMUM "max"

#define BP_SALT_MINIMUM "BeatPass.v1.normal.10"
#define BP_SALT_MEDIUM "BeatPass.v1.medium.18"
#define BP_SALT_MAXIMUM "BeatPass.v1.maximum.28"

#endif
