#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>

#include "beatpass_crypto.h"
#include "argon2.h"

int bp_argon2id_seed(const char *secret_utf8,
                     size_t secret_len,
                     const unsigned char *salt,
                     size_t salt_len,
                     unsigned char out_seed[64]) {
    int rc;

    if (!secret_utf8 || !salt || !out_seed) {
        return 0;
    }

    rc = argon2id_hash_raw(3,
                           64 * 1024,
                           2,
                           secret_utf8,
                           secret_len,
                           salt,
                           salt_len,
                           out_seed,
                           64);
    return rc == ARGON2_OK;
}

int bp_hmac_sha256(const unsigned char *key,
                   size_t key_len,
                   const unsigned char *data,
                   size_t data_len,
                   unsigned char out_digest[32]) {
    BCRYPT_ALG_HANDLE alg = NULL;
    BCRYPT_HASH_HANDLE hash = NULL;
    NTSTATUS status;
    int ok = 0;

    if (!key || !data || !out_digest) {
        return 0;
    }

    status = BCryptOpenAlgorithmProvider(&alg,
                                         BCRYPT_SHA256_ALGORITHM,
                                         NULL,
                                         BCRYPT_ALG_HANDLE_HMAC_FLAG);
    if (status < 0) {
        goto done;
    }

    status = BCryptCreateHash(alg,
                              &hash,
                              NULL,
                              0,
                              (PUCHAR)key,
                              (ULONG)key_len,
                              0);
    if (status < 0) {
        goto done;
    }

    status = BCryptHashData(hash, (PUCHAR)data, (ULONG)data_len, 0);
    if (status < 0) {
        goto done;
    }

    status = BCryptFinishHash(hash, out_digest, 32, 0);
    if (status < 0) {
        goto done;
    }

    ok = 1;

done:
    if (hash) {
        BCryptDestroyHash(hash);
    }
    if (alg) {
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    return ok;
}
