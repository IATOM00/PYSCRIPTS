#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

#include "beatpass.h"
#include "beatpass_crypto.h"
#include "beatpass_unicode.h"
#include "BeatPass.context.local.h"

#define MIN_SECRET_LENGTH 5
#define MIN_KEYBOARD_SEQUENCE_LENGTH 3
#define MIN_REPEAT_RUN_LENGTH 3

static const char PASSWORD_CONTEXT_PREFIX[] = "BeatPass.password.v1.";

static const char LOWERCASE[] = "abcdefghijkmnopqrstuvwxyz";
static const char UPPERCASE[] = "ABCDEFGHJKLMNPQRSTUVWXYZ";
static const char DIGITS[] = "1234567890";
static const char SPECIAL_CHARS[] = "!#$%&*+-=?@_";
static const char PASSWORD_ALPHABET[] =
    "abcdefghijkmnopqrstuvwxyz"
    "ABCDEFGHJKLMNPQRSTUVWXYZ"
    "1234567890"
    "!#$%&*+-=?@_";

static const char *REQUIRED_CATEGORIES[] = {
    LOWERCASE,
    UPPERCASE,
    DIGITS,
    SPECIAL_CHARS,
};

static const bp_profile PROFILES[] = {
    {L"minimum", BP_CONTEXT_KEY_MINIMUM, (const unsigned char *)BP_SALT_MINIMUM, sizeof(BP_SALT_MINIMUM) - 1, 10},
    {L"medium", BP_CONTEXT_KEY_MEDIUM, (const unsigned char *)BP_SALT_MEDIUM, sizeof(BP_SALT_MEDIUM) - 1, 18},
    {L"maximum", BP_CONTEXT_KEY_MAXIMUM, (const unsigned char *)BP_SALT_MAXIMUM, sizeof(BP_SALT_MAXIMUM) - 1, 28},
};

static const wchar_t *KEYBOARD_ROWS[] = {
    L"`1234567890-=",
    L"qwertyuiop[]\\",
    L"asdfghjkl;'",
    L"zxcvbnm,./",
    L"йцукенгшщзхї",
    L"фівапролджє",
    L"ячсмитбью.",
};

static const wchar_t *WEAK_DICTIONARY_WORDS[] = {
    L"administrator",
    L"password",
    L"secret",
    L"секрет",
    L"archive",
    L"welcome",
    L"архів",
    L"backup",
    L"default",
    L"guest",
    L"admin",
    L"codex",
    L"login",
    L"пароль",
    L"гість",
    L"дефолт",
};

static void set_error(wchar_t *error, size_t error_cap, const wchar_t *message) {
    if (!error || error_cap == 0) {
        return;
    }
    if (!message) {
        error[0] = L'\0';
        return;
    }
    wcsncpy(error, message, error_cap - 1);
    error[error_cap - 1] = L'\0';
}

static void set_error_fmt(wchar_t *error,
                          size_t error_cap,
                          const wchar_t *format,
                          const wchar_t *value) {
    if (!error || error_cap == 0) {
        return;
    }
    _snwprintf(error, error_cap, format, value ? value : L"");
    error[error_cap - 1] = L'\0';
}

const wchar_t *bp_default_difficulty(void) {
    return L"maximum";
}

const bp_profile *bp_get_profile(const wchar_t *difficulty) {
    size_t i;
    const wchar_t *key = difficulty ? difficulty : bp_default_difficulty();

    if (wcscmp(key, L"normal") == 0) {
        key = L"minimum";
    }

    for (i = 0; i < sizeof(PROFILES) / sizeof(PROFILES[0]); ++i) {
        if (wcscmp(PROFILES[i].name, key) == 0) {
            return &PROFILES[i];
        }
    }

    return NULL;
}

static int has_adjacent_repeat(const wchar_t *text,
                               wchar_t *out_repeat,
                               size_t repeat_cap) {
    wchar_t run_char;
    size_t run_len = 1;
    size_t longest_len = 0;
    wchar_t longest_char = L'\0';
    size_t i;

    if (!text || !text[0]) {
        return 0;
    }

    run_char = text[0];
    for (i = 1; text[i]; ++i) {
        if (text[i] == run_char) {
            ++run_len;
        } else {
            if (run_len >= MIN_REPEAT_RUN_LENGTH && run_len > longest_len) {
                longest_len = run_len;
                longest_char = run_char;
            }
            run_char = text[i];
            run_len = 1;
        }
    }

    if (run_len >= MIN_REPEAT_RUN_LENGTH && run_len > longest_len) {
        longest_len = run_len;
        longest_char = run_char;
    }

    if (longest_len == 0) {
        return 0;
    }

    if (out_repeat && repeat_cap > 0) {
        size_t count = longest_len < repeat_cap - 1 ? longest_len : repeat_cap - 1;
        for (i = 0; i < count; ++i) {
            out_repeat[i] = longest_char;
        }
        out_repeat[count] = L'\0';
    }
    return 1;
}

static size_t find_index(const wchar_t *haystack, const wchar_t *needle) {
    wchar_t *found = wcsstr(haystack, needle);
    if (!found) {
        return (size_t)-1;
    }
    return (size_t)(found - haystack);
}

static int find_keyboard_sequence(const wchar_t *text,
                                  wchar_t *out_sequence,
                                  size_t sequence_cap) {
    wchar_t *compact;
    size_t best_len = 0;
    size_t best_index = (size_t)-1;
    size_t row_idx;

    if (!text || !out_sequence || sequence_cap == 0) {
        return 0;
    }
    out_sequence[0] = L'\0';

    compact = bp_remove_spaces(text);
    if (!compact) {
        return 0;
    }

    for (row_idx = 0; row_idx < sizeof(KEYBOARD_ROWS) / sizeof(KEYBOARD_ROWS[0]);
         ++row_idx) {
        const wchar_t *row = KEYBOARD_ROWS[row_idx];
        size_t row_len = wcslen(row);
        size_t size;

        for (size = row_len; size >= MIN_KEYBOARD_SEQUENCE_LENGTH; --size) {
            size_t start;
            for (start = 0; start + size <= row_len; ++start) {
                wchar_t forward[64];
                wchar_t reverse[64];
                size_t i;
                size_t index;

                if (size >= sizeof(forward) / sizeof(forward[0])) {
                    continue;
                }

                for (i = 0; i < size; ++i) {
                    forward[i] = row[start + i];
                    reverse[i] = row[start + size - i - 1];
                }
                forward[size] = L'\0';
                reverse[size] = L'\0';

                index = find_index(compact, forward);
                if (index != (size_t)-1 &&
                    (size > best_len || (size == best_len && index < best_index))) {
                    best_len = size;
                    best_index = index;
                    wcsncpy(out_sequence, forward, sequence_cap - 1);
                    out_sequence[sequence_cap - 1] = L'\0';
                }

                index = find_index(compact, reverse);
                if (index != (size_t)-1 &&
                    (size > best_len || (size == best_len && index < best_index))) {
                    best_len = size;
                    best_index = index;
                    wcsncpy(out_sequence, reverse, sequence_cap - 1);
                    out_sequence[sequence_cap - 1] = L'\0';
                }
            }
            if (size == MIN_KEYBOARD_SEQUENCE_LENGTH) {
                break;
            }
        }
    }

    free(compact);
    return best_len > 0;
}

static const wchar_t *find_dictionary_word(const wchar_t *text) {
    wchar_t *compact;
    size_t i;

    if (!text) {
        return NULL;
    }

    compact = bp_remove_spaces(text);
    if (!compact) {
        return NULL;
    }

    for (i = 0; i < sizeof(WEAK_DICTIONARY_WORDS) / sizeof(WEAK_DICTIONARY_WORDS[0]);
         ++i) {
        if (wcsstr(compact, WEAK_DICTIONARY_WORDS[i])) {
            const wchar_t *word = WEAK_DICTIONARY_WORDS[i];
            free(compact);
            return word;
        }
    }

    free(compact);
    return NULL;
}

static int validate_secret(const wchar_t *secret,
                           wchar_t **out_normalized,
                           wchar_t *error,
                           size_t error_cap) {
    wchar_t *normalized = NULL;
    wchar_t *checked = NULL;
    wchar_t repeat[64];
    wchar_t sequence[64];
    const wchar_t *weak_word;
    int ok = 0;

    if (!secret) {
        set_error(error, error_cap, L"Секрет не задано.");
        return 0;
    }

    if (bp_has_outer_space(secret)) {
        set_error(error,
                  error_cap,
                  L"Секрет не повинен починатися або завершуватися пробілом.");
        return 0;
    }

    if (!bp_nfkc(secret, &normalized)) {
        set_error(error, error_cap, L"Не вдалося нормалізувати Unicode секрет.");
        return 0;
    }

    if (bp_codepoint_len(normalized) < MIN_SECRET_LENGTH) {
        wchar_t message[128];
        _snwprintf(message,
                   sizeof(message) / sizeof(message[0]),
                   L"Коротка послідовність: < %d символів.",
                   MIN_SECRET_LENGTH);
        message[(sizeof(message) / sizeof(message[0])) - 1] = L'\0';
        set_error(error, error_cap, message);
        goto done;
    }

    if (!bp_casefold(normalized, &checked)) {
        set_error(error, error_cap, L"Не вдалося виконати Unicode casefold.");
        goto done;
    }

    if (has_adjacent_repeat(checked, repeat, sizeof(repeat) / sizeof(repeat[0]))) {
        set_error_fmt(error, error_cap, L"Символьна послідовність: '%ls'.", repeat);
        goto done;
    }

    if (find_keyboard_sequence(checked,
                               sequence,
                               sizeof(sequence) / sizeof(sequence[0]))) {
        set_error_fmt(error,
                      error_cap,
                      L"Клавіатурна послідовність: '%ls'.",
                      sequence);
        goto done;
    }

    weak_word = find_dictionary_word(checked);
    if (weak_word) {
        set_error_fmt(error,
                      error_cap,
                      L"Словникова послідовність: '%ls'.",
                      weak_word);
        goto done;
    }

    *out_normalized = normalized;
    normalized = NULL;
    ok = 1;

done:
    free(checked);
    free(normalized);
    return ok;
}

static int expand_bytes(const unsigned char seed[64],
                        const char *context_key,
                        unsigned char *out,
                        size_t out_len) {
    unsigned char digest[32];
    unsigned char data[128];
    const size_t prefix_len = sizeof(PASSWORD_CONTEXT_PREFIX) - 1;
    const size_t key_len = strlen(context_key);
    size_t produced = 0;
    uint32_t counter = 1;

    if (prefix_len + key_len + 4 > sizeof(data)) {
        return 0;
    }

    memcpy(data, PASSWORD_CONTEXT_PREFIX, prefix_len);
    memcpy(data + prefix_len, context_key, key_len);

    while (produced < out_len) {
        size_t chunk;
        data[prefix_len + key_len + 0] = (unsigned char)((counter >> 24) & 0xFF);
        data[prefix_len + key_len + 1] = (unsigned char)((counter >> 16) & 0xFF);
        data[prefix_len + key_len + 2] = (unsigned char)((counter >> 8) & 0xFF);
        data[prefix_len + key_len + 3] = (unsigned char)(counter & 0xFF);

        if (!bp_hmac_sha256(seed, 64, data, prefix_len + key_len + 4, digest)) {
            return 0;
        }

        chunk = out_len - produced;
        if (chunk > sizeof(digest)) {
            chunk = sizeof(digest);
        }
        memcpy(out + produced, digest, chunk);
        produced += chunk;
        ++counter;
    }

    return 1;
}

static char pick_char(unsigned char source_byte, const char *alphabet) {
    return alphabet[source_byte % strlen(alphabet)];
}

static void pick_distinct_positions(const unsigned char *stream,
                                    size_t stream_len,
                                    size_t count,
                                    size_t length,
                                    size_t *positions) {
    size_t found = 0;
    size_t cursor = 0;

    while (found < count) {
        size_t i;
        size_t position = stream[cursor % stream_len] % length;
        int exists = 0;
        ++cursor;
        for (i = 0; i < found; ++i) {
            if (positions[i] == position) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            positions[found++] = position;
        }
    }
}

int bp_generate_key(const wchar_t *secret,
                    const wchar_t *difficulty,
                    char out_password[BP_MAX_PASSWORD_LEN + 1],
                    wchar_t *error,
                    size_t error_cap) {
    const bp_profile *profile = bp_get_profile(difficulty);
    wchar_t *normalized = NULL;
    char *secret_utf8 = NULL;
    size_t secret_utf8_len = 0;
    unsigned char seed[64];
    unsigned char stream[BP_MAX_PASSWORD_LEN * 4];
    size_t positions[4];
    size_t stream_len;
    size_t pos_stream_offset;
    size_t pos_stream_len;
    size_t i;
    size_t cursor;
    int ok = 0;

    if (!out_password) {
        return BP_ERR_INVALID_ARGUMENT;
    }
    out_password[0] = '\0';
    set_error(error, error_cap, NULL);

    if (!profile) {
        wchar_t message[192];
        _snwprintf(message,
                   sizeof(message) / sizeof(message[0]),
                   L"Невідома складність '%ls'. Доступно: maximum, medium, minimum.",
                   difficulty ? difficulty : L"");
        message[(sizeof(message) / sizeof(message[0])) - 1] = L'\0';
        set_error(error, error_cap, message);
        return BP_ERR_INVALID_ARGUMENT;
    }

    if (!validate_secret(secret, &normalized, error, error_cap)) {
        return BP_ERR_VALIDATION;
    }

    if (!bp_to_utf8(normalized, &secret_utf8, &secret_utf8_len)) {
        set_error(error, error_cap, L"Не вдалося перетворити секрет у UTF-8.");
        goto done;
    }

    if (!bp_argon2id_seed(secret_utf8,
                          secret_utf8_len,
                          profile->salt,
                          profile->salt_len,
                          seed)) {
        set_error(error, error_cap, L"Помилка Argon2id генерації.");
        goto done;
    }

    stream_len = profile->length * 4;
    if (!expand_bytes(seed, profile->context_key, stream, stream_len)) {
        set_error(error, error_cap, L"Помилка HMAC-SHA256 розширення.");
        goto done;
    }

    for (i = 0; i < profile->length; ++i) {
        out_password[i] = pick_char(stream[i], PASSWORD_ALPHABET);
    }
    out_password[profile->length] = '\0';

    pos_stream_offset = profile->length;
    pos_stream_len = stream_len - pos_stream_offset;
    if (pos_stream_len > 32) {
        pos_stream_len = 32;
    }
    pick_distinct_positions(stream + pos_stream_offset,
                            pos_stream_len,
                            sizeof(REQUIRED_CATEGORIES) / sizeof(REQUIRED_CATEGORIES[0]),
                            profile->length,
                            positions);

    cursor = profile->length + 32;
    for (i = 0; i < sizeof(REQUIRED_CATEGORIES) / sizeof(REQUIRED_CATEGORIES[0]);
         ++i) {
        out_password[positions[i]] =
            pick_char(stream[cursor % stream_len], REQUIRED_CATEGORIES[i]);
        ++cursor;
    }

    ok = 1;

done:
    free(secret_utf8);
    free(normalized);
    if (!ok) {
        out_password[0] = '\0';
        return BP_ERR_CRYPTO;
    }
    return BP_OK;
}
