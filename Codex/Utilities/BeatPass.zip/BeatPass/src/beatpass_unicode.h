#ifndef BEATPASS_UNICODE_H
#define BEATPASS_UNICODE_H

#include <stddef.h>
#include <wchar.h>

int bp_nfkc(const wchar_t *input, wchar_t **out);
int bp_casefold(const wchar_t *input, wchar_t **out);
int bp_to_utf8(const wchar_t *input, char **out, size_t *out_len);
size_t bp_codepoint_len(const wchar_t *text);
int bp_is_space(wchar_t ch);
int bp_has_outer_space(const wchar_t *text);
wchar_t *bp_remove_spaces(const wchar_t *text);

#endif
