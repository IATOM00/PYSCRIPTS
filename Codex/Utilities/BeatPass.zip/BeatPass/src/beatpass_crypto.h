#ifndef BEATPASS_CRYPTO_H
#define BEATPASS_CRYPTO_H

#include <stddef.h>

int bp_argon2id_seed(const char *secret_utf8,
                     size_t secret_len,
                     const unsigned char *salt,
                     size_t salt_len,
                     unsigned char out_seed[64]);

int bp_hmac_sha256(const unsigned char *key,
                   size_t key_len,
                   const unsigned char *data,
                   size_t data_len,
                   unsigned char out_digest[32]);

#endif
