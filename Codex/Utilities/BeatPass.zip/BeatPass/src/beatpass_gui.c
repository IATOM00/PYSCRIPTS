#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <dwmapi.h>

#include <stdio.h>
#include <string.h>
#include <wchar.h>

#include "beatpass.h"
#include "resource.h"

#define IDC_SECRET 1001
#define IDC_DIFFICULTY 1002
#define IDC_GENERATE 1003
#define IDC_RESULT 1004
#define IDC_NOTICE 1005

#define IDM_DIFFICULTY_MAXIMUM 2001
#define IDM_DIFFICULTY_MEDIUM 2002
#define IDM_DIFFICULTY_MINIMUM 2003

#define RGB_UI_BG RGB(244, 247, 251)
#define RGB_UI_SURFACE RGB(255, 255, 255)
#define RGB_UI_FIELD RGB(255, 255, 255)
#define RGB_UI_FG RGB(21, 32, 43)
#define RGB_UI_MUTED RGB(97, 112, 132)
#define RGB_UI_WARNING RGB(143, 31, 31)
#define RGB_UI_BORDER RGB(214, 222, 232)
#define RGB_UI_ACTIVE RGB(15, 118, 110)
#define RGB_UI_SEPARATOR RGB(214, 222, 232)
#define RGB_UI_CONTROL RGB(232, 238, 245)
#define RGB_UI_HEADER RGB(16, 60, 58)
#define RGB_UI_ACTION RGB(255, 255, 255)
#define RGB_UI_ACTION_HOVER RGB(232, 238, 245)
#define RGB_UI_ACTION_PRESSED RGB(214, 222, 232)
#define RGB_UI_SUCCESS RGB(15, 118, 110)

static const wchar_t APP_TITLE[] = L"ГЕНЕРАТОР КЛЮЧІВ & ПАРОЛІВ";
static const wchar_t SECRET_HINT[] =
    L"Мінімум 5 символів, без вразливих послідовностей.";
static const wchar_t COPY_CONFIRMATION[] =
    L"Готово! Ключ скопійовано в буфер обміну!";

typedef struct app_state {
    HWND hwnd;
    HWND secret;
    HWND difficulty;
    HWND result;
    HWND notice;
    HWND generate;
    HFONT ui_font;
    HFONT bold_font;
    HFONT mono_font;
    HFONT symbol_font;
    HBRUSH bg_brush;
    HBRUSH surface_brush;
    HBRUSH field_brush;
    WNDPROC old_secret_proc;
    RECT panel_rect;
    RECT content_rect;
    RECT accent_rect;
    RECT secret_box_rect;
    RECT result_box_rect;
    RECT difficulty_rect;
    RECT generate_box_rect;
    wchar_t difficulty_value[16];
    int suppress_change;
    int result_mode;
    int notice_visible;
} app_state;

static app_state g_app;

static void apply_dark_title_bar(HWND hwnd) {
    BOOL enabled = TRUE;
    DwmSetWindowAttribute(hwnd, 20, &enabled, sizeof(enabled));
    DwmSetWindowAttribute(hwnd, 19, &enabled, sizeof(enabled));
}

static HFONT make_font(const wchar_t *name, int point_size, int weight) {
    HDC dc = GetDC(NULL);
    int height = -MulDiv(point_size, GetDeviceCaps(dc, LOGPIXELSY), 72);
    ReleaseDC(NULL, dc);
    return CreateFontW(height,
                       0,
                       0,
                       0,
                       weight,
                       FALSE,
                       FALSE,
                       FALSE,
                       DEFAULT_CHARSET,
                       OUT_DEFAULT_PRECIS,
                       CLIP_DEFAULT_PRECIS,
                       CLEARTYPE_QUALITY,
                       DEFAULT_PITCH | FF_DONTCARE,
                       name);
}

static void set_control_font(HWND hwnd, HFONT font) {
    SendMessageW(hwnd, WM_SETFONT, (WPARAM)font, TRUE);
}

static void fill_rect_color(HDC hdc, const RECT *rect, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    FillRect(hdc, rect, brush);
    DeleteObject(brush);
}

static RECT inset_rect(RECT rect, int dx, int dy) {
    InflateRect(&rect, -dx, -dy);
    return rect;
}

static void draw_field_box(HDC hdc, const RECT *rect, int active) {
    RECT inner = inset_rect(*rect, 1, 1);
    fill_rect_color(hdc, rect, active ? RGB_UI_ACTIVE : RGB_UI_BORDER);
    fill_rect_color(hdc, &inner, RGB_UI_FIELD);
}

static const wchar_t *difficulty_display_text(void) {
    if (wcscmp(g_app.difficulty_value, L"minimum") == 0) {
        return L"min \x25BE";
    }
    if (wcscmp(g_app.difficulty_value, L"medium") == 0) {
        return L"med \x25BE";
    }
    return L"max \x25BE";
}

static void center_window(HWND hwnd) {
    RECT rect;
    RECT work;
    HMONITOR monitor;
    MONITORINFO mi;
    int width;
    int height;
    int x;
    int y;

    GetWindowRect(hwnd, &rect);
    width = rect.right - rect.left;
    height = rect.bottom - rect.top;

    monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
    mi.cbSize = sizeof(mi);
    if (GetMonitorInfoW(monitor, &mi)) {
        work = mi.rcWork;
    } else {
        work.left = 0;
        work.top = 0;
        work.right = GetSystemMetrics(SM_CXSCREEN);
        work.bottom = GetSystemMetrics(SM_CYSCREEN);
    }

    x = work.left + ((work.right - work.left) - width) / 2;
    y = work.top + ((work.bottom - work.top) - height) / 2;
    if (x < work.left) {
        x = work.left;
    }
    if (y < work.top) {
        y = work.top;
    }

    SetWindowPos(hwnd, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
}

static void set_result_text(const wchar_t *text, int mode) {
    g_app.suppress_change = 1;
    g_app.result_mode = mode;
    SetWindowTextW(g_app.result, text);
    InvalidateRect(g_app.result, NULL, TRUE);
    g_app.suppress_change = 0;
}

static void hide_secret_notice(int focus_secret) {
    g_app.notice_visible = 0;
    ShowWindow(g_app.notice, SW_HIDE);
    ShowWindow(g_app.secret, SW_SHOW);
    ShowWindow(g_app.difficulty, SW_SHOW);
    if (focus_secret) {
        SetFocus(g_app.secret);
    }
    InvalidateRect(g_app.hwnd, &g_app.secret_box_rect, TRUE);
}

static void reset_result(void) {
    SetWindowTextW(g_app.notice, L"");
    hide_secret_notice(0);
    set_result_text(SECRET_HINT, 0);
}

static void show_secret_notice(const wchar_t *text) {
    g_app.notice_visible = 1;
    SetWindowTextW(g_app.notice, text);
    ShowWindow(g_app.secret, SW_HIDE);
    ShowWindow(g_app.difficulty, SW_HIDE);
    ShowWindow(g_app.notice, SW_SHOW);
    InvalidateRect(g_app.hwnd, &g_app.secret_box_rect, TRUE);
}

static void ascii_to_wide(const char *input, wchar_t *out, size_t out_cap) {
    MultiByteToWideChar(CP_UTF8, 0, input, -1, out, (int)out_cap);
    out[out_cap - 1] = L'\0';
}

static void copy_to_clipboard(HWND hwnd, const wchar_t *text) {
    size_t bytes = (wcslen(text) + 1) * sizeof(wchar_t);
    HGLOBAL memory;
    void *locked;

    if (!OpenClipboard(hwnd)) {
        return;
    }

    EmptyClipboard();
    memory = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!memory) {
        CloseClipboard();
        return;
    }

    locked = GlobalLock(memory);
    if (!locked) {
        GlobalFree(memory);
        CloseClipboard();
        return;
    }

    memcpy(locked, text, bytes);
    GlobalUnlock(memory);
    SetClipboardData(CF_UNICODETEXT, memory);
    CloseClipboard();
}

static void selected_difficulty(wchar_t *out, size_t out_cap) {
    wcsncpy(out, g_app.difficulty_value, out_cap - 1);
    out[out_cap - 1] = L'\0';
}

static void generate_password(HWND hwnd) {
    wchar_t secret[512];
    wchar_t difficulty[32];
    wchar_t error[BP_ERROR_CAP];
    wchar_t password_wide[BP_MAX_PASSWORD_LEN + 1];
    char password[BP_MAX_PASSWORD_LEN + 1];
    int rc;

    GetWindowTextW(g_app.secret, secret, (int)(sizeof(secret) / sizeof(secret[0])));
    secret[(sizeof(secret) / sizeof(secret[0])) - 1] = L'\0';
    selected_difficulty(difficulty, sizeof(difficulty) / sizeof(difficulty[0]));

    rc = bp_generate_key(secret,
                         difficulty,
                         password,
                         error,
                         sizeof(error) / sizeof(error[0]));
    if (rc != BP_OK) {
        set_result_text(error, 2);
        hide_secret_notice(1);
        return;
    }

    ascii_to_wide(password, password_wide, sizeof(password_wide) / sizeof(password_wide[0]));
    set_result_text(password_wide, 1);
    copy_to_clipboard(hwnd, password_wide);
    show_secret_notice(COPY_CONFIRMATION);
}

static void choose_difficulty(HWND hwnd) {
    HMENU menu = CreatePopupMenu();
    RECT rect;
    int command;

    if (!menu) {
        return;
    }

    AppendMenuW(menu, MF_STRING, IDM_DIFFICULTY_MAXIMUM, L"maximum");
    AppendMenuW(menu, MF_STRING, IDM_DIFFICULTY_MEDIUM, L"medium");
    AppendMenuW(menu, MF_STRING, IDM_DIFFICULTY_MINIMUM, L"minimum");

    if (wcscmp(g_app.difficulty_value, L"maximum") == 0) {
        CheckMenuItem(menu, IDM_DIFFICULTY_MAXIMUM, MF_CHECKED);
    } else if (wcscmp(g_app.difficulty_value, L"medium") == 0) {
        CheckMenuItem(menu, IDM_DIFFICULTY_MEDIUM, MF_CHECKED);
    } else {
        CheckMenuItem(menu, IDM_DIFFICULTY_MINIMUM, MF_CHECKED);
    }

    GetWindowRect(g_app.difficulty, &rect);
    command = TrackPopupMenu(menu,
                             TPM_LEFTALIGN | TPM_TOPALIGN | TPM_RETURNCMD,
                             rect.left,
                             rect.bottom + 1,
                             0,
                             hwnd,
                             NULL);
    DestroyMenu(menu);

    if (command == IDM_DIFFICULTY_MAXIMUM) {
        wcscpy(g_app.difficulty_value, L"maximum");
    } else if (command == IDM_DIFFICULTY_MEDIUM) {
        wcscpy(g_app.difficulty_value, L"medium");
    } else if (command == IDM_DIFFICULTY_MINIMUM) {
        wcscpy(g_app.difficulty_value, L"minimum");
    } else {
        return;
    }

    InvalidateRect(g_app.difficulty, NULL, TRUE);
    reset_result();
}

static void layout_controls(HWND hwnd) {
    RECT rc;
    RECT shell;
    RECT panel;
    RECT content;
    RECT secret_inner;
    RECT result_inner;
    int window_pad_x = 18;
    int window_pad_y = 16;
    int panel_pad_x = 14;
    int panel_pad_y = 14;
    int row_gap = 10;
    int field_h = 38;
    int generate_w = 62;
    int generate_gap = 10;
    int difficulty_w = 68;
    int secret_edit_pad_x = 10;
    int edit_h = 24;
    int edit_y;
    int edit_offset_y = 3;
    int field_right;

    GetClientRect(hwnd, &rc);

    shell.left = window_pad_x;
    shell.top = window_pad_y;
    shell.right = rc.right - window_pad_x;
    shell.bottom = rc.bottom - window_pad_y;

    panel = inset_rect(shell, 1, 1);
    content = panel;
    InflateRect(&content, -panel_pad_x, -panel_pad_y);

    g_app.panel_rect = panel;
    g_app.content_rect = content;
    g_app.accent_rect.left = content.left;
    g_app.accent_rect.top = content.top;
    g_app.accent_rect.right = content.right;
    g_app.accent_rect.bottom = content.top + 3;

    g_app.generate_box_rect.right = content.right;
    g_app.generate_box_rect.left = content.right - generate_w;
    g_app.generate_box_rect.top = g_app.accent_rect.bottom + 12;
    g_app.generate_box_rect.bottom = g_app.generate_box_rect.top + field_h * 2 + row_gap;

    field_right = g_app.generate_box_rect.left - generate_gap;
    g_app.secret_box_rect.left = content.left;
    g_app.secret_box_rect.top = g_app.generate_box_rect.top;
    g_app.secret_box_rect.right = field_right;
    g_app.secret_box_rect.bottom = g_app.secret_box_rect.top + field_h;

    g_app.result_box_rect.left = content.left;
    g_app.result_box_rect.top = g_app.secret_box_rect.bottom + row_gap;
    g_app.result_box_rect.right = field_right;
    g_app.result_box_rect.bottom = g_app.result_box_rect.top + field_h;

    secret_inner = inset_rect(g_app.secret_box_rect, 1, 1);
    result_inner = inset_rect(g_app.result_box_rect, 1, 1);

    g_app.difficulty_rect.left = secret_inner.right - difficulty_w;
    g_app.difficulty_rect.top = secret_inner.top;
    g_app.difficulty_rect.right = secret_inner.right;
    g_app.difficulty_rect.bottom = secret_inner.bottom;

    edit_y = secret_inner.top +
             ((secret_inner.bottom - secret_inner.top) - edit_h) / 2 +
             edit_offset_y;
    MoveWindow(g_app.secret,
               secret_inner.left + secret_edit_pad_x,
               edit_y,
               g_app.difficulty_rect.left - secret_inner.left - secret_edit_pad_x - 7,
               edit_h,
               TRUE);
    MoveWindow(g_app.notice,
               secret_inner.left,
               edit_y,
               secret_inner.right - secret_inner.left,
               edit_h,
               TRUE);
    MoveWindow(g_app.difficulty,
               g_app.difficulty_rect.left,
               g_app.difficulty_rect.top,
               g_app.difficulty_rect.right - g_app.difficulty_rect.left,
               g_app.difficulty_rect.bottom - g_app.difficulty_rect.top,
               TRUE);

    edit_y = result_inner.top +
             ((result_inner.bottom - result_inner.top) - edit_h) / 2 +
             edit_offset_y;
    MoveWindow(g_app.result,
               result_inner.left + 10,
               edit_y,
               result_inner.right - result_inner.left - 20,
               edit_h,
               TRUE);
    MoveWindow(g_app.generate,
               g_app.generate_box_rect.left + 1,
               g_app.generate_box_rect.top + 1,
               g_app.generate_box_rect.right - g_app.generate_box_rect.left - 2,
               g_app.generate_box_rect.bottom - g_app.generate_box_rect.top - 2,
               TRUE);
}

static LRESULT CALLBACK secret_proc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
    if (message == WM_KEYDOWN && wparam == VK_RETURN) {
        generate_password(g_app.hwnd);
        return 0;
    }
    return CallWindowProcW(g_app.old_secret_proc, hwnd, message, wparam, lparam);
}

static int create_controls(HWND hwnd) {
    g_app.ui_font = make_font(L"Segoe UI", 10, FW_NORMAL);
    g_app.bold_font = make_font(L"Segoe UI", 10, FW_BOLD);
    g_app.mono_font = make_font(L"Cascadia Mono", 9, FW_NORMAL);
    g_app.symbol_font = make_font(L"Segoe UI Symbol", 10, FW_BOLD);
    g_app.bg_brush = CreateSolidBrush(RGB_UI_BG);
    g_app.surface_brush = CreateSolidBrush(RGB_UI_SURFACE);
    g_app.field_brush = CreateSolidBrush(RGB_UI_FIELD);
    wcscpy(g_app.difficulty_value, L"maximum");

    g_app.secret = CreateWindowExW(0,
                                   L"EDIT",
                                   L"",
                                   WS_CHILD | WS_VISIBLE | WS_TABSTOP |
                                       ES_AUTOHSCROLL | ES_CENTER,
                                   0,
                                   0,
                                   0,
                                   0,
                                   hwnd,
                                   (HMENU)IDC_SECRET,
                                   GetModuleHandleW(NULL),
                                   NULL);
    g_app.difficulty = CreateWindowExW(0,
                                       L"BUTTON",
                                       L"",
                                       WS_CHILD | WS_VISIBLE | WS_TABSTOP |
                                           BS_OWNERDRAW,
                                       0,
                                       0,
                                       0,
                                       0,
                                       hwnd,
                                       (HMENU)IDC_DIFFICULTY,
                                       GetModuleHandleW(NULL),
                                       NULL);
    g_app.generate = CreateWindowExW(0,
                                     L"BUTTON",
                                     L"",
                                     WS_CHILD | WS_VISIBLE | WS_TABSTOP |
                                         BS_OWNERDRAW | BS_DEFPUSHBUTTON,
                                     0,
                                     0,
                                     0,
                                     0,
                                     hwnd,
                                     (HMENU)IDC_GENERATE,
                                     GetModuleHandleW(NULL),
                                     NULL);
    g_app.result = CreateWindowExW(0,
                                   L"EDIT",
                                   SECRET_HINT,
                                   WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL |
                                       ES_CENTER | ES_READONLY,
                                   0,
                                   0,
                                   0,
                                   0,
                                   hwnd,
                                   (HMENU)IDC_RESULT,
                                   GetModuleHandleW(NULL),
                                   NULL);
    g_app.notice = CreateWindowExW(0,
                                   L"STATIC",
                                   L"",
                                   WS_CHILD | SS_CENTER | SS_NOTIFY,
                                   0,
                                   0,
                                   0,
                                   0,
                                   hwnd,
                                   (HMENU)IDC_NOTICE,
                                   GetModuleHandleW(NULL),
                                   NULL);

    if (!g_app.secret || !g_app.difficulty || !g_app.generate || !g_app.result ||
        !g_app.notice) {
        return 0;
    }

    set_control_font(g_app.secret, g_app.ui_font);
    set_control_font(g_app.difficulty, g_app.bold_font);
    set_control_font(g_app.generate, g_app.symbol_font);
    set_control_font(g_app.result, g_app.mono_font);
    set_control_font(g_app.notice, g_app.bold_font);

    g_app.old_secret_proc =
        (WNDPROC)SetWindowLongPtrW(g_app.secret, GWLP_WNDPROC, (LONG_PTR)secret_proc);

    layout_controls(hwnd);
    SetFocus(g_app.secret);
    return 1;
}

static void draw_button_text(HDC hdc, const RECT *rect, const wchar_t *text, COLORREF color) {
    HFONT old_font;
    RECT text_rect = *rect;

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, color);
    old_font = (HFONT)SelectObject(hdc, g_app.bold_font);
    DrawTextW(hdc,
              text,
              -1,
              &text_rect,
              DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    SelectObject(hdc, old_font);
}

static void draw_generate_button(HDC hdc, const RECT *rect, UINT state) {
    COLORREF fill = (state & ODS_SELECTED) ? RGB_UI_ACTION_PRESSED : RGB_UI_ACTION;
    RECT border = *rect;
    RECT inner = inset_rect(*rect, 1, 1);
    fill_rect_color(hdc, &border, RGB_UI_BORDER);
    fill_rect_color(hdc, &inner, fill);
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 0, 0));
    SelectObject(hdc, g_app.symbol_font);
    DrawTextW(hdc, L"\x25B6", -1, (RECT *)rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void draw_difficulty_button(HDC hdc, const RECT *rect, UINT state) {
    COLORREF fill = (state & ODS_SELECTED) ? RGB_UI_ACTION_HOVER : RGB_UI_CONTROL;
    RECT text_rect = *rect;
    fill_rect_color(hdc, rect, fill);
    InflateRect(&text_rect, -2, 0);
    draw_button_text(hdc, &text_rect, difficulty_display_text(), RGB_UI_FG);
}

static void paint_window(HWND hwnd) {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    RECT rc;
    RECT shell;
    RECT inner;
    HWND focus = GetFocus();

    GetClientRect(hwnd, &rc);
    FillRect(hdc, &rc, g_app.bg_brush);

    shell = g_app.panel_rect;
    InflateRect(&shell, 1, 1);
    fill_rect_color(hdc, &shell, RGB_UI_BORDER);
    FillRect(hdc, &g_app.panel_rect, g_app.surface_brush);
    fill_rect_color(hdc, &g_app.accent_rect, RGB_UI_HEADER);

    draw_field_box(hdc, &g_app.secret_box_rect, focus == g_app.secret);
    draw_field_box(hdc, &g_app.result_box_rect, focus == g_app.result);

    fill_rect_color(hdc, &g_app.generate_box_rect, RGB_UI_BORDER);

    if (!g_app.notice_visible) {
        inner = inset_rect(g_app.secret_box_rect, 1, 1);
        inner.left = g_app.difficulty_rect.left - 1;
        inner.right = inner.left + 1;
        fill_rect_color(hdc, &inner, RGB_UI_SEPARATOR);
    }

    EndPaint(hwnd, &ps);
}

static LRESULT CALLBACK window_proc(HWND hwnd,
                                    UINT message,
                                    WPARAM wparam,
                                    LPARAM lparam) {
    switch (message) {
    case WM_CREATE:
        g_app.hwnd = hwnd;
        apply_dark_title_bar(hwnd);
        if (!create_controls(hwnd)) {
            return -1;
        }
        return 0;

    case WM_SIZE:
        layout_controls(hwnd);
        InvalidateRect(hwnd, NULL, TRUE);
        return 0;

    case WM_COMMAND:
        if (LOWORD(wparam) == IDC_GENERATE && HIWORD(wparam) == BN_CLICKED) {
            generate_password(hwnd);
            return 0;
        }
        if (LOWORD(wparam) == IDC_DIFFICULTY && HIWORD(wparam) == BN_CLICKED) {
            choose_difficulty(hwnd);
            return 0;
        }
        if (LOWORD(wparam) == IDC_NOTICE && HIWORD(wparam) == STN_CLICKED) {
            hide_secret_notice(1);
            return 0;
        }
        if (LOWORD(wparam) == IDC_SECRET && HIWORD(wparam) == EN_CHANGE &&
            !g_app.suppress_change) {
            reset_result();
            return 0;
        }
        if ((LOWORD(wparam) == IDC_SECRET || LOWORD(wparam) == IDC_RESULT) &&
            (HIWORD(wparam) == EN_SETFOCUS || HIWORD(wparam) == EN_KILLFOCUS)) {
            InvalidateRect(hwnd, NULL, TRUE);
            return 0;
        }
        return 0;

    case WM_DRAWITEM: {
        DRAWITEMSTRUCT *item = (DRAWITEMSTRUCT *)lparam;
        if (item->CtlID == IDC_GENERATE) {
            draw_generate_button(item->hDC, &item->rcItem, item->itemState);
            return TRUE;
        }
        if (item->CtlID == IDC_DIFFICULTY) {
            draw_difficulty_button(item->hDC, &item->rcItem, item->itemState);
            return TRUE;
        }
        return FALSE;
    }

    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)wparam;
        HWND control = (HWND)lparam;
        SetBkColor(hdc, RGB_UI_FIELD);
        if (control == g_app.result) {
            if (g_app.result_mode == 2) {
                SetTextColor(hdc, RGB_UI_WARNING);
            } else if (g_app.result_mode == 1) {
                SetTextColor(hdc, RGB_UI_FG);
            } else {
                SetTextColor(hdc, RGB_UI_MUTED);
            }
        } else {
            SetTextColor(hdc, RGB_UI_FG);
        }
        return (LRESULT)g_app.field_brush;
    }

    case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wparam;
        HWND control = (HWND)lparam;
        SetBkColor(hdc, RGB_UI_FIELD);
        SetTextColor(hdc, control == g_app.notice ? RGB_UI_SUCCESS : RGB_UI_FG);
        return (LRESULT)g_app.field_brush;
    }

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT:
        paint_window(hwnd);
        return 0;

    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        if (g_app.ui_font) {
            DeleteObject(g_app.ui_font);
        }
        if (g_app.bold_font) {
            DeleteObject(g_app.bold_font);
        }
        if (g_app.mono_font) {
            DeleteObject(g_app.mono_font);
        }
        if (g_app.symbol_font) {
            DeleteObject(g_app.symbol_font);
        }
        if (g_app.bg_brush) {
            DeleteObject(g_app.bg_brush);
        }
        if (g_app.surface_brush) {
            DeleteObject(g_app.surface_brush);
        }
        if (g_app.field_brush) {
            DeleteObject(g_app.field_brush);
        }
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcW(hwnd, message, wparam, lparam);
}

int bp_gui_run(void) {
    HINSTANCE instance = GetModuleHandleW(NULL);
    INITCOMMONCONTROLSEX icc;
    WNDCLASSEXW wc;
    HWND hwnd;
    MSG msg;
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    DWORD ex_style = WS_EX_TOPMOST;
    RECT rect = {0, 0, 520, 166};
    HICON icon;

    memset(&g_app, 0, sizeof(g_app));

    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&icc);

    icon = (HICON)LoadImageW(instance,
                             MAKEINTRESOURCEW(IDI_BEATPASS),
                             IMAGE_ICON,
                             0,
                             0,
                             LR_DEFAULTSIZE);

    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = window_proc;
    wc.hInstance = instance;
    wc.hIcon = icon ? icon : LoadIconW(NULL, IDI_APPLICATION);
    wc.hIconSm = icon ? icon : LoadIconW(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszClassName = L"BeatPassNativeWindow";

    if (!RegisterClassExW(&wc)) {
        return 1;
    }

    AdjustWindowRectEx(&rect, style, FALSE, ex_style);
    hwnd = CreateWindowExW(ex_style,
                           wc.lpszClassName,
                           APP_TITLE,
                           style,
                           CW_USEDEFAULT,
                           CW_USEDEFAULT,
                           rect.right - rect.left,
                           rect.bottom - rect.top,
                           NULL,
                           NULL,
                           instance,
                           NULL);
    if (!hwnd) {
        return 1;
    }

    center_window(hwnd);
    ShowWindow(hwnd, SW_SHOWNORMAL);
    UpdateWindow(hwnd);
    SetForegroundWindow(hwnd);

    while (GetMessageW(&msg, NULL, 0, 0) > 0) {
        if (msg.hwnd && msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN) {
            generate_password(hwnd);
            continue;
        }
        if (!IsDialogMessageW(hwnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }

    return (int)msg.wParam;
}
