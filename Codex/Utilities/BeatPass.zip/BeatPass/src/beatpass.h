#ifndef BEATPASS_H
#define BEATPASS_H

#include <stddef.h>
#include <wchar.h>

#define BP_MAX_PASSWORD_LEN 28
#define BP_ERROR_CAP 512

typedef enum bp_status {
    BP_OK = 0,
    BP_ERR_INVALID_ARGUMENT = 1,
    BP_ERR_VALIDATION = 2,
    BP_ERR_CRYPTO = 3,
    BP_ERR_SYSTEM = 4
} bp_status;

typedef struct bp_profile {
    const wchar_t *name;
    const char *context_key;
    const unsigned char *salt;
    size_t salt_len;
    size_t length;
} bp_profile;

const bp_profile *bp_get_profile(const wchar_t *difficulty);
const wchar_t *bp_default_difficulty(void);
int bp_generate_key(const wchar_t *secret,
                    const wchar_t *difficulty,
                    char out_password[BP_MAX_PASSWORD_LEN + 1],
                    wchar_t *error,
                    size_t error_cap);

int bp_gui_run(void);

#endif
