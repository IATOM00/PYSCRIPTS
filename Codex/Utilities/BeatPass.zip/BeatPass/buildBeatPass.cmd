@echo off
setlocal

set "ROOT=%~dp0"
set "BUILD_PS1=%ROOT%build.ps1"
set "ZIG_VERSION=0.13.0"
set "TEMP_ZIG_DIR=%TEMP%\zig-windows-x86_64-%ZIG_VERSION%"
set "TEMP_ZIG=%TEMP_ZIG_DIR%\zig.exe"

echo Stopping running BeatPass.exe instances, if any...
taskkill /f /im BeatPass.exe >nul 2>nul

set "BEATPASS_WAIT=0"
:wait_for_beatpass_exit
tasklist /fi "imagename eq BeatPass.exe" 2>nul | find /i "BeatPass.exe" >nul
if errorlevel 1 goto beatpass_stopped
timeout /t 1 /nobreak >nul
set /a BEATPASS_WAIT+=1
if %BEATPASS_WAIT% lss 10 goto wait_for_beatpass_exit

echo BeatPass.exe is still running. Close it manually or run this script as administrator.
exit /b 1

:beatpass_stopped

if exist "%ROOT%build" rd /q /s "%ROOT%build"
if exist "%ROOT%BeatPass.pdb" del /q "%ROOT%BeatPass.pdb"

if not exist "%BUILD_PS1%" (
    echo Build script not found: "%BUILD_PS1%"
    exit /b 1
)

where cl.exe >nul 2>nul
if not errorlevel 1 goto compiler_ready
where clang.exe >nul 2>nul
if not errorlevel 1 goto compiler_ready
where gcc.exe >nul 2>nul
if not errorlevel 1 goto compiler_ready
where zig.exe >nul 2>nul
if not errorlevel 1 goto compiler_ready

if exist "%TEMP_ZIG%" (
    echo Using portable Zig from "%TEMP_ZIG_DIR%"
    set "PATH=%TEMP_ZIG_DIR%;%PATH%"
    goto compiler_ready
)

echo No C compiler found.
echo Install MSVC Build Tools, LLVM/clang, MinGW gcc, or put zig.exe in PATH.
echo Portable Zig was also not found at "%TEMP_ZIG%".
exit /b 1

:compiler_ready

pushd "%ROOT%" || exit /b 1
echo Building BeatPass.exe
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%BUILD_PS1%"
set "BUILD_EXIT=%ERRORLEVEL%"
popd

if "%BUILD_EXIT%"=="0" (
    if exist "%ROOT%build" rd /q /s "%ROOT%build"
    if exist "%ROOT%BeatPass.pdb" del /q "%ROOT%BeatPass.pdb"
)

exit /b %BUILD_EXIT%
