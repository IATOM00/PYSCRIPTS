from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXE = ROOT / "BeatPass.exe"
FIXTURES = ROOT / "tests" / "fixtures.json"


def run_python(secret: str, difficulty: str) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    proc = subprocess.run(
        [
            sys.executable,
            str(ROOT / "BeatPass.py"),
            "--secret",
            secret,
            "--difficulty",
            difficulty,
        ],
        cwd=ROOT,
        env=env,
        text=True,
        encoding="utf-8",
        capture_output=True,
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def run_c(secret: str, difficulty: str) -> tuple[int, str, str]:
    proc = subprocess.run(
        [
            str(EXE),
            "--secret",
            secret,
            "--difficulty",
            difficulty,
        ],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def main() -> int:
    fixtures = json.loads(FIXTURES.read_text(encoding="utf-8"))
    failures: list[str] = []

    if not EXE.exists():
        print(f"Missing {EXE}. Run .\\build.ps1 first.", file=sys.stderr)
        return 1

    for case in fixtures:
        secret = case["secret"]
        difficulty = case["difficulty"]
        expected = case["password"]

        py_rc, py_out, py_err = run_python(secret, difficulty)
        if py_rc != 0 or py_out != expected:
            failures.append(
                f"Python oracle mismatch for {secret!r}/{difficulty}: "
                f"rc={py_rc} out={py_out!r} err={py_err!r}"
            )
            continue

        c_rc, c_out, c_err = run_c(secret, difficulty)
        if c_rc != 0 or c_out != expected:
            failures.append(
                f"C mismatch for {secret!r}/{difficulty}: "
                f"rc={c_rc} out={c_out!r} err={c_err!r}; expected={expected!r}"
            )

    validation_cases = [
        ("abcd", "maximum"),
        (" Correct Horse Battery 2026!", "maximum"),
        ("Correct Horse Battery 2026! ", "maximum"),
        ("aaaaa", "maximum"),
        ("qwerty 2026!", "maximum"),
        ("my secret 2026!", "maximum"),
    ]
    for secret, difficulty in validation_cases:
        py_rc, _, _ = run_python(secret, difficulty)
        c_rc, _, c_err = run_c(secret, difficulty)
        if py_rc == 0 or c_rc == 0:
            failures.append(
                f"Validation mismatch for {secret!r}/{difficulty}: "
                f"python rc={py_rc}, C rc={c_rc}, C err={c_err!r}"
            )

    if failures:
        for failure in failures:
            print(failure, file=sys.stderr)
        return 1

    print(f"OK: {len(fixtures)} parity fixtures and {len(validation_cases)} validation cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
